'use client';

import { Container } from '@/lib/docker/types';
import { ContainerCard } from './container-card';
import { Loading } from '@/components/ui/loading';
import { ErrorMessage } from '@/components/ui/error-message';
import { Button } from '@/components/ui/button';
import { RefreshCwIcon } from 'lucide-react';

interface ContainerListProps {
  containers: Container[];
  isLoading: boolean;
  error: string | null;
  onRefresh: () => void;
}

export function ContainerList({ 
  containers, 
  isLoading, 
  error, 
  onRefresh 
}: ContainerListProps) {
  if (isLoading) {
    return <Loading />;
  }

  if (error) {
    return (
      <div className="space-y-4">
        <ErrorMessage message={error} />
        <Button onClick={onRefresh} variant="outline" size="sm">
          <RefreshCwIcon className="mr-2 h-4 w-4" />
          Try again
        </Button>
      </div>
    );
  }

  if (containers.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-lg border border-dashed p-8 text-center">
        <h3 className="mb-2 text-lg font-medium">No containers found</h3>
        <p className="text-sm text-muted-foreground">
          Get started by creating a new container.
        </p>
      </div>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {containers.map((container) => (
        <ContainerCard 
          key={container.Id} 
          container={container}
          onStatusChange={onRefresh}
        />
      ))}
    </div>
  );
}