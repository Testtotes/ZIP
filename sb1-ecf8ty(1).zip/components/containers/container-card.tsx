'use client';

import { useState } from 'react';
import { Container } from '@/lib/docker/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { 
  PlayIcon, 
  StopIcon, 
  TrashIcon,
  ExternalLinkIcon,
  RefreshCwIcon
} from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

interface ContainerCardProps {
  container: Container;
  onStatusChange: () => void;
}

export function ContainerCard({ container, onStatusChange }: ContainerCardProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  async function handleAction(action: 'start' | 'stop' | 'remove') {
    try {
      setIsLoading(true);
      const response = await fetch(`/api/containers/${container.Id}/${action}`, {
        method: 'POST',
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || `Failed to ${action} container`);
      }

      toast({
        title: 'Success',
        description: `Container ${action}ed successfully`,
      });

      onStatusChange();
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'An error occurred',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }

  const containerUrl = `http://${container.Names[0].replace('/', '')}.dockersphere.ovh`;

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-base font-medium">
          {container.Names[0].replace('/', '')}
        </CardTitle>
        <ContainerStatus state={container.State} />
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Image:</span>
            <span className="font-medium">{container.Image}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Status:</span>
            <span className="font-medium">{container.Status}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Port:</span>
            <span className="font-medium">
              {container.Ports.map(p => `${p.PublicPort}:${p.PrivatePort}`).join(', ')}
            </span>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {container.State === 'running' ? (
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleAction('stop')}
              disabled={isLoading}
            >
              <StopIcon className="mr-2 h-4 w-4" />
              Stop
            </Button>
          ) : (
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleAction('start')}
              disabled={isLoading}
            >
              <PlayIcon className="mr-2 h-4 w-4" />
              Start
            </Button>
          )}

          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="sm">
                <TrashIcon className="mr-2 h-4 w-4" />
                Remove
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently remove the
                  container and all its data.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => handleAction('remove')}
                  className="bg-destructive text-destructive-foreground"
                >
                  Remove
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          {container.State === 'running' && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open(containerUrl, '_blank')}
            >
              <ExternalLinkIcon className="mr-2 h-4 w-4" />
              Open
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

function ContainerStatus({ state }: { state: string }) {
  const stateColors = {
    running: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100',
    exited: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100',
    created: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100',
  };

  return (
    <span
      className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${
        stateColors[state as keyof typeof stateColors] ||
        'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-100'
      }`}
    >
      {state}
    </span>
  );
}