export function Loading() {
  return (
    <div className="text-center">
      <p className="text-lg">Loading containers...</p>
    </div>
  );
}