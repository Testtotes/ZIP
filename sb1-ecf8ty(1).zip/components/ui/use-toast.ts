// Simplified toast hook for notifications
import { useToast as useToastOriginal } from '@/components/ui/toast';

export function useToast() {
  return useToastOriginal();
}