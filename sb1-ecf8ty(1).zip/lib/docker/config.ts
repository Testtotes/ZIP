export const DOCKER_SOCKET = process.env.DOCKER_SOCKET || '/var/run/docker.sock';
export const DOCKER_HOST = process.env.DOCKER_HOST;
export const DOCKER_PORT = process.env.DOCKER_PORT || '2375';
export const DOCKER_VERSION = process.env.DOCKER_VERSION || 'v1.41';