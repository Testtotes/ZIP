import Docker from 'dockerode';
import { DOCKER_HOST, DOCKER_PORT, DOCKER_SOCKET } from './config';

let dockerClient: Docker | null = null;

export function getDockerClient(): Docker {
  if (!dockerClient) {
    if (DOCKER_HOST) {
      dockerClient = new Docker({
        host: DOCKER_HOST,
        port: parseInt(DOCKER_PORT),
      });
    } else {
      dockerClient = new Docker({ socketPath: DOCKER_SOCKET });
    }
  }
  return dockerClient;
}