import { NextResponse } from 'next/server';
import { getDockerClient } from '@/lib/docker/client';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

const createContainerSchema = z.object({
  name: z.string(),
  image: z.string(),
  port: z.number(),
});

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const docker = getDockerClient();
    const containers = await docker.listContainers({ all: true });
    
    // Filter containers by user if not admin
    if (session.user.role !== 'ADMIN') {
      const userContainers = await prisma.container.findMany({
        where: { userId: session.user.id },
        select: { id: true },
      });
      const userContainerIds = new Set(userContainers.map(c => c.id));
      return NextResponse.json({
        containers: containers.filter(c => userContainerIds.has(c.Id)),
      });
    }

    return NextResponse.json({ containers });
  } catch (error) {
    console.error('Container API error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch containers' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { name, image, port } = createContainerSchema.parse(body);

    const docker = getDockerClient();

    // Create container
    const container = await docker.createContainer({
      Image: image,
      name,
      ExposedPorts: {
        [`${port}/tcp`]: {},
      },
      HostConfig: {
        PortBindings: {
          [`${port}/tcp`]: [{ HostPort: '0' }], // Dynamically assign port
        },
      },
    });

    // Start container
    await container.start();

    // Get container info to get assigned port
    const containerInfo = await container.inspect();
    const publicPort = containerInfo.NetworkSettings.Ports[`${port}/tcp`][0].HostPort;

    // Save container to database
    await prisma.container.create({
      data: {
        id: container.id,
        name,
        image,
        port: parseInt(publicPort),
        status: 'running',
        url: `http://${name}.dockersphere.ovh`,
        userId: session.user.id,
      },
    });

    return NextResponse.json({
      success: true,
      container: containerInfo,
    });
  } catch (error) {
    console.error('Create container error:', error);
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid input', details: error.errors },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: 'Failed to create container' },
      { status: 500 }
    );
  }
}