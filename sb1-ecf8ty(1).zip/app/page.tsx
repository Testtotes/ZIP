'use client';

import { useEffect, useState } from 'react';
import { Container } from '@/lib/docker/types';
import { ContainerList } from '@/components/containers/container-list';
import { Loading } from '@/components/ui/loading';
import { ErrorMessage } from '@/components/ui/error-message';

export default function Home() {
  const [containers, setContainers] = useState<Container[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchContainers() {
      try {
        const response = await fetch('/api/containers');
        const data = await response.json();
        if (data.error) {
          throw new Error(data.error);
        }
        setContainers(data.containers);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch containers');
      } finally {
        setLoading(false);
      }
    }

    fetchContainers();
  }, []);

  return (
    <main className="container mx-auto py-8">
      <h1 className="text-4xl font-bold mb-8">Docker Containers</h1>
      
      {loading && <Loading />}
      {error && <ErrorMessage message={error} />}
      {!loading && !error && <ContainerList containers={containers} />}
    </main>
  );
}