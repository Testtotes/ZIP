import { useState, useEffect } from 'react';
import axios from 'axios';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import UsersList from './UsersList';
import SystemStats from './SystemStats';

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    totalContainers: 0,
    activeContainers: 0,
    totalMemoryUsage: 0,
    totalCpuUsage: 0,
    availablePorts: 0,
  });

  const [usageHistory, setUsageHistory] = useState([]);

  useEffect(() => {
    fetchStats();
    const interval = setInterval(fetchStats, 30000);
    return () => clearInterval(interval);
  }, []);

  const fetchStats = async () => {
    try {
      const response = await axios.get('/api/admin/stats');
      setStats(response.data);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <h1 className="text-4xl font-bold text-gray-900">Admin Dashboard</h1>
        
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
          <SystemStats stats={stats} />
          
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Resource Usage History</h2>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={usageHistory}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="timestamp" />
                  <YAxis />
                  <Tooltip />
                  <Area 
                    type="monotone" 
                    dataKey="memoryUsage" 
                    stroke="#8884d8" 
                    fill="#8884d8" 
                    name="Memory Usage (GB)"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="cpuUsage" 
                    stroke="#82ca9d" 
                    fill="#82ca9d" 
                    name="CPU Usage (%)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <UsersList />
      </div>
    </div>
  );
}