import ContainerList from '@/components/ContainerList';
import CreateContainer from '@/components/CreateContainer';

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <h1 className="text-4xl font-bold text-gray-900">Docker Container Management</h1>
        <CreateContainer />
        <ContainerList />
      </div>
    </main>
  );
}