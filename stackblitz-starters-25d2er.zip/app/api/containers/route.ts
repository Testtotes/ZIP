import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../auth/[...nextauth]/route';
import { PrismaClient } from '@prisma/client';
import Docker from 'dockerode';
import { QuotaManager } from '@/lib/quota-manager';
import { PortManager } from '@/lib/port-manager';
import { NginxManager } from '@/lib/nginx-manager';

const prisma = new PrismaClient();
const docker = new Docker();
const quotaManager = new QuotaManager();
const portManager = new PortManager();
const nginxManager = new NginxManager();

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const containers = await prisma.container.findMany({
      where: {
        user: {
          email: session.user.email
        }
      }
    });

    return NextResponse.json(containers);
  } catch (error) {
    console.error('Error fetching containers:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { image, name, subdomain, containerPort, memoryLimit, cpuLimit } = body;

    const user = await prisma.user.findUnique({
      where: { email: session.user.email }
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Check quotas
    await quotaManager.checkContainerQuota(user.id);
    await quotaManager.checkResourceQuota(user.id, memoryLimit, cpuLimit);

    // Allocate port
    const hostPort = await portManager.allocatePort();

    // Create container
    const container = await docker.createContainer({
      Image: image,
      name,
      ExposedPorts: {
        [`${containerPort}/tcp`]: {}
      },
      HostConfig: {
        PortBindings: {
          [`${containerPort}/tcp`]: [{ HostPort: hostPort.toString() }]
        },
        Memory: memoryLimit * 1024 * 1024 * 1024,
        NanoCPUs: Math.floor(cpuLimit * 1e9)
      }
    });

    await container.start();

    // Update nginx config
    await nginxManager.updatePortMapping(subdomain, hostPort);

    // Save to database
    const dbContainer = await prisma.container.create({
      data: {
        dockerId: container.id,
        name,
        image,
        subdomain,
        hostPort,
        containerPort,
        memoryLimit,
        cpuLimit,
        status: 'running',
        userId: user.id
      }
    });

    return NextResponse.json(dbContainer);
  } catch (error) {
    console.error('Error creating container:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}