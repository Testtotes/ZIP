import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../../auth/[...nextauth]/route';
import { PrismaClient } from '@prisma/client';
import Docker from 'dockerode';

const prisma = new PrismaClient();
const docker = new Docker();

export async function POST(
  req: Request,
  { params }: { params: { id: string; action: string } }
) {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const container = await prisma.container.findUnique({
      where: { id: parseInt(params.id) },
      include: { user: true }
    });

    if (!container) {
      return NextResponse.json({ error: 'Container not found' }, { status: 404 });
    }

    if (container.user.email !== session.user.email && !session.user.isAdmin) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const dockerContainer = docker.getContainer(container.dockerId);

    switch (params.action) {
      case 'start':
        await dockerContainer.start();
        await prisma.container.update({
          where: { id: container.id },
          data: { status: 'running' }
        });
        break;

      case 'stop':
        await dockerContainer.stop();
        await prisma.container.update({
          where: { id: container.id },
          data: { status: 'stopped' }
        });
        break;

      case 'delete':
        await dockerContainer.remove({ force: true });
        await prisma.container.delete({
          where: { id: container.id }
        });
        break;

      default:
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error(`Error ${params.action} container:`, error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}