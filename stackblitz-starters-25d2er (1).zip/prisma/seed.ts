import { PrismaClient } from '@prisma/client';
import { hash } from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  // Create admin user
  const password = await hash('admin123', 10);
  
  await prisma.user.upsert({
    where: { email: 'admin@dockerflow.com' },
    update: {},
    create: {
      email: 'admin@dockerflow.com',
      username: 'admin',
      password,
      isAdmin: true,
      maxContainers: 10,
      maxMemory: 8,
      maxCpu: 4,
    },
  });

  // Initialize port pool
  const ports = Array.from({ length: 1000 }, (_, i) => ({
    port: 10000 + i,
    isAllocated: false,
  }));

  await prisma.portAllocation.createMany({
    data: ports,
    skipDuplicates: true,
  });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });