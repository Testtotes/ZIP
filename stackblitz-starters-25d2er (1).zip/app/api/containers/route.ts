import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../auth/[...nextauth]/route';
import { ContainerManager } from '@/lib/container-manager';

const containerManager = new ContainerManager();

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const containers = await containerManager.listContainers(parseInt(session.user.id));
    return NextResponse.json(containers);
  } catch (error) {
    console.error('Error fetching containers:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const container = await containerManager.createContainer(parseInt(session.user.id), body);
    return NextResponse.json(container);
  } catch (error) {
    console.error('Error creating container:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}