import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../../auth/[...nextauth]/route';
import { ContainerManager } from '@/lib/container-manager';

const containerManager = new ContainerManager();

export async function POST(
  req: Request,
  { params }: { params: { id: string; action: string } }
) {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const containerId = parseInt(params.id);
    const userId = parseInt(session.user.id);

    switch (params.action) {
      case 'start':
      case 'stop':
        await containerManager.updateContainerStatus(containerId, userId, params.action);
        break;

      case 'delete':
        await containerManager.deleteContainer(containerId, userId);
        break;

      default:
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error(`Error ${params.action} container:`, error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}