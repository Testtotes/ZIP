import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../auth/[...nextauth]/route';
import { PrismaClient } from '@prisma/client';
import Docker from 'dockerode';

const prisma = new PrismaClient();
const docker = new Docker();

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.isAdmin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const [containers, ports] = await Promise.all([
      prisma.container.findMany(),
      prisma.portAllocation.findMany()
    ]);

    const dockerContainers = await docker.listContainers({ all: true });
    
    const stats = {
      totalContainers: containers.length,
      activeContainers: containers.filter(c => c.status === 'running').length,
      totalMemoryUsage: containers.reduce((acc, c) => acc + c.memoryLimit, 0),
      totalCpuUsage: containers.reduce((acc, c) => acc + c.cpuLimit, 0),
      availablePorts: ports.filter(p => !p.isAllocated).length
    };

    return NextResponse.json(stats);
  } catch (error) {
    console.error('Error fetching admin stats:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}