/** @type {import('next').NextConfig} */
const nextConfig = {
  webpack: (config, { isServer }) => {
    // Ignore native addons
    config.resolve.fallback = {
      ...config.resolve.fallback,
      "ssh2": false
    };
    return config;
  },
  images: {
    unoptimized: true
  }
};

module.exports = nextConfig;