import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export class QuotaManager {
  async checkContainerQuota(userId: number): Promise<void> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        _count: {
          select: { containers: true }
        }
      }
    });

    if (!user) {
      throw new Error('User not found');
    }

    if (user._count.containers >= user.maxContainers) {
      throw new Error('Container quota exceeded');
    }
  }

  async checkResourceQuota(userId: number, memoryLimit: number, cpuLimit: number): Promise<void> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        containers: {
          select: {
            memoryLimit: true,
            cpuLimit: true
          }
        }
      }
    });

    if (!user) {
      throw new Error('User not found');
    }

    const totalMemory = user.containers.reduce((sum, container) => sum + container.memoryLimit, 0) + memoryLimit;
    const totalCpu = user.containers.reduce((sum, container) => sum + container.cpuLimit, 0) + cpuLimit;

    if (totalMemory > user.maxMemory) {
      throw new Error('Memory quota exceeded');
    }

    if (totalCpu > user.maxCpu) {
      throw new Error('CPU quota exceeded');
    }
  }
}