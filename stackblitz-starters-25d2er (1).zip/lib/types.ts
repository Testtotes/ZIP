export interface Container {
  id: number;
  dockerId: string;
  name: string;
  image: string;
  subdomain: string;
  hostPort: number;
  containerPort: number;
  memoryLimit: number;
  cpuLimit: number;
  status: string;
  userId: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface User {
  id: number;
  email: string;
  username: string;
  isActive: boolean;
  isAdmin: boolean;
  maxContainers: number;
  maxMemory: number;
  maxCpu: number;
}

export interface PortAllocation {
  id: number;
  port: number;
  isAllocated: boolean;
  containerId: number | null;
  createdAt: Date;
  updatedAt: Date;
}