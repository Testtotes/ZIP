import { promises as fs } from 'fs';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export class NginxManager {
  private configDir: string;
  private nginxReloadCommand: string;

  constructor(configDir = '/etc/nginx/conf.d', reloadCommand = 'nginx -s reload') {
    this.configDir = configDir;
    this.nginxReloadCommand = reloadCommand;
  }

  async updatePortMapping(subdomain: string, port: number): Promise<void> {
    const config = this.generateNginxConfig(subdomain, port);
    const configPath = `${this.configDir}/${subdomain}.conf`;

    try {
      await fs.writeFile(configPath, config);
      await execAsync(this.nginxReloadCommand);
    } catch (error) {
      console.error('Error updating Nginx configuration:', error);
      throw new Error('Failed to update Nginx configuration');
    }
  }

  async removePortMapping(subdomain: string): Promise<void> {
    const configPath = `${this.configDir}/${subdomain}.conf`;

    try {
      await fs.unlink(configPath);
      await execAsync(this.nginxReloadCommand);
    } catch (error) {
      console.error('Error removing Nginx configuration:', error);
      throw new Error('Failed to remove Nginx configuration');
    }
  }

  private generateNginxConfig(subdomain: string, port: number): string {
    return `server {
    listen 80;
    server_name ${subdomain}.localhost;

    location / {
        proxy_pass http://localhost:${port};
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}`;
  }
}