import { PrismaClient } from '@prisma/client';
import Docker from 'dockerode';
import { Container } from './types';
import { QuotaManager } from './quota-manager';
import { PortManager } from './port-manager';
import { NginxManager } from './nginx-manager';

const prisma = new PrismaClient();
const docker = new Docker();
const quotaManager = new QuotaManager();
const portManager = new PortManager();
const nginxManager = new NginxManager();

export class ContainerManager {
  async createContainer(
    userId: number,
    data: {
      image: string;
      name: string;
      subdomain: string;
      containerPort: number;
      memoryLimit: number;
      cpuLimit: number;
    }
  ): Promise<Container> {
    // Check quotas
    await quotaManager.checkContainerQuota(userId);
    await quotaManager.checkResourceQuota(userId, data.memoryLimit, data.cpuLimit);

    // Allocate port
    const hostPort = await portManager.allocatePort();

    try {
      // Create container
      const container = await docker.createContainer({
        Image: data.image,
        name: data.name,
        ExposedPorts: {
          [`${data.containerPort}/tcp`]: {}
        },
        HostConfig: {
          PortBindings: {
            [`${data.containerPort}/tcp`]: [{ HostPort: hostPort.toString() }]
          },
          Memory: data.memoryLimit * 1024 * 1024 * 1024,
          NanoCPUs: Math.floor(data.cpuLimit * 1e9)
        }
      });

      await container.start();

      // Update nginx config
      await nginxManager.updatePortMapping(data.subdomain, hostPort);

      // Save to database
      const dbContainer = await prisma.container.create({
        data: {
          dockerId: container.id,
          name: data.name,
          image: data.image,
          subdomain: data.subdomain,
          hostPort,
          containerPort: data.containerPort,
          memoryLimit: data.memoryLimit,
          cpuLimit: data.cpuLimit,
          status: 'running',
          userId
        }
      });

      return dbContainer;
    } catch (error) {
      // Cleanup on failure
      await portManager.releasePort(hostPort);
      throw error;
    }
  }

  async deleteContainer(containerId: number, userId: number): Promise<void> {
    const container = await prisma.container.findUnique({
      where: { id: containerId }
    });

    if (!container) {
      throw new Error('Container not found');
    }

    if (container.userId !== userId) {
      throw new Error('Unauthorized');
    }

    const dockerContainer = docker.getContainer(container.dockerId);
    await dockerContainer.remove({ force: true });
    await nginxManager.removePortMapping(container.subdomain);
    await portManager.releasePort(container.hostPort);
    await prisma.container.delete({
      where: { id: containerId }
    });
  }

  async updateContainerStatus(containerId: number, userId: number, action: 'start' | 'stop'): Promise<void> {
    const container = await prisma.container.findUnique({
      where: { id: containerId }
    });

    if (!container) {
      throw new Error('Container not found');
    }

    if (container.userId !== userId) {
      throw new Error('Unauthorized');
    }

    const dockerContainer = docker.getContainer(container.dockerId);

    if (action === 'start') {
      await dockerContainer.start();
      await prisma.container.update({
        where: { id: containerId },
        data: { status: 'running' }
      });
    } else {
      await dockerContainer.stop();
      await prisma.container.update({
        where: { id: containerId },
        data: { status: 'stopped' }
      });
    }
  }

  async listContainers(userId: number): Promise<Container[]> {
    return prisma.container.findMany({
      where: { userId }
    });
  }
}