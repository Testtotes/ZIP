"use client";

import { useState, useEffect } from 'react';
import axios from 'axios';

interface AdminStats {
  totalContainers: number;
  activeContainers: number;
  totalMemoryUsage: number;
  totalCpuUsage: number;
  availablePorts: number;
}

export function useAdminStats() {
  const [stats, setStats] = useState<AdminStats>({
    totalContainers: 0,
    activeContainers: 0,
    totalMemoryUsage: 0,
    totalCpuUsage: 0,
    availablePorts: 0,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchStats = async () => {
    try {
      const response = await axios.get('/api/admin/stats');
      setStats(response.data);
      setError(null);
    } catch (err) {
      setError('Error fetching stats');
      console.error('Error fetching stats:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
    const interval = setInterval(fetchStats, 30000);
    return () => clearInterval(interval);
  }, []);

  return {
    stats,
    loading,
    error,
    refreshStats: fetchStats
  };
}