"use client";

import { useState, useEffect } from 'react';
import axios from 'axios';
import { Container } from '../types';

export function useContainers() {
  const [containers, setContainers] = useState<Container[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchContainers = async () => {
    try {
      const response = await axios.get('/api/containers');
      setContainers(response.data);
      setError(null);
    } catch (err) {
      setError('Error fetching containers');
      console.error('Error fetching containers:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleContainerAction = async (id: string, action: 'start' | 'stop' | 'delete') => {
    try {
      await axios.post(`/api/containers/${id}/${action}`);
      await fetchContainers();
    } catch (err) {
      setError(`Error ${action}ing container`);
      console.error(`Error ${action}ing container:`, err);
    }
  };

  useEffect(() => {
    fetchContainers();
  }, []);

  return {
    containers,
    loading,
    error,
    handleContainerAction,
    refreshContainers: fetchContainers
  };
}