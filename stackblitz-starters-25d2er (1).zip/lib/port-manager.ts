import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export class PortManager {
  async allocatePort(): Promise<number> {
    const availablePort = await prisma.portAllocation.findFirst({
      where: { isAllocated: false },
      orderBy: { port: 'asc' }
    });

    if (!availablePort) {
      throw new Error('No available ports');
    }

    await prisma.portAllocation.update({
      where: { id: availablePort.id },
      data: { isAllocated: true }
    });

    return availablePort.port;
  }

  async releasePort(port: number): Promise<void> {
    await prisma.portAllocation.updateMany({
      where: { port },
      data: { isAllocated: false }
    });
  }
}