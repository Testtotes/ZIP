"use client";

import { useAdminStats } from '@/lib/hooks/useAdminStats';
import UsersList from './UsersList';
import SystemStats from './SystemStats';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function AdminDashboard() {
  const { stats, loading, error } = useAdminStats();

  if (loading) {
    return <div>Loading dashboard...</div>;
  }

  if (error) {
    return <div className="text-red-600">{error}</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <h1 className="text-4xl font-bold text-gray-900">Admin Dashboard</h1>
        
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
          <SystemStats stats={stats} />
          
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Resource Usage History</h2>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={[]}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="timestamp" />
                  <YAxis />
                  <Tooltip />
                  <Area 
                    type="monotone" 
                    dataKey="memoryUsage" 
                    stroke="#8884d8" 
                    fill="#8884d8" 
                    name="Memory Usage (GB)"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="cpuUsage" 
                    stroke="#82ca9d" 
                    fill="#82ca9d" 
                    name="CPU Usage (%)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <UsersList />
      </div>
    </div>
  );
}