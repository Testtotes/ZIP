"use client";

import { useState } from 'react';
import axios from 'axios';

export default function CreateContainer() {
  const [formData, setFormData] = useState({
    image: '',
    name: '',
    subdomain: '',
    containerPort: 80,
    memoryLimit: 1,
    cpuLimit: 1,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await axios.post('/api/containers', formData);
      setFormData({
        image: '',
        name: '',
        subdomain: '',
        containerPort: 80,
        memoryLimit: 1,
        cpuLimit: 1,
      });
    } catch (error) {
      console.error('Error creating container:', error);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  return (
    <div className="bg-white shadow rounded-lg">
      <div className="px-4 py-5 sm:p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Create New Container</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="image" className="block text-sm font-medium text-gray-700">
                Docker Image
              </label>
              <input
                type="text"
                name="image"
                id="image"
                value={formData.image}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="nginx:latest"
                required
              />
            </div>
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                Container Name
              </label>
              <input
                type="text"
                name="name"
                id="name"
                value={formData.name}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="my-nginx"
                required
              />
            </div>
            <div>
              <label htmlFor="subdomain" className="block text-sm font-medium text-gray-700">
                Subdomain
              </label>
              <input
                type="text"
                name="subdomain"
                id="subdomain"
                value={formData.subdomain}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="myapp"
                required
              />
            </div>
            <div>
              <label htmlFor="containerPort" className="block text-sm font-medium text-gray-700">
                Container Port
              </label>
              <input
                type="number"
                name="containerPort"
                id="containerPort"
                value={formData.containerPort}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                min="1"
                max="65535"
                required
              />
            </div>
            <div>
              <label htmlFor="memoryLimit" className="block text-sm font-medium text-gray-700">
                Memory Limit (GB)
              </label>
              <input
                type="number"
                name="memoryLimit"
                id="memoryLimit"
                value={formData.memoryLimit}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                min="0.1"
                max="32"
                step="0.1"
                required
              />
            </div>
            <div>
              <label htmlFor="cpuLimit" className="block text-sm font-medium text-gray-700">
                CPU Limit (cores)
              </label>
              <input
                type="number"
                name="cpuLimit"
                id="cpuLimit"
                value={formData.cpuLimit}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                min="0.1"
                max="8"
                step="0.1"
                required
              />
            </div>
          </div>
          <div className="flex justify-end">
            <button
              type="submit"
              className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              Create Container
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}